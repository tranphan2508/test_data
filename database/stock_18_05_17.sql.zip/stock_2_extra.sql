
--
-- Indexes for dumped tables
--

--
-- Indexes for table `f_detail`
--
ALTER TABLE `f_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `p_template`
--
ALTER TABLE `p_template`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `f_detail`
--
ALTER TABLE `f_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=544;
--
-- AUTO_INCREMENT for table `params`
--
ALTER TABLE `params`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;