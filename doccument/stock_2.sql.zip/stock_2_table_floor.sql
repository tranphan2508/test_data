
-- --------------------------------------------------------

--
-- Table structure for table `floor`
--

DROP TABLE IF EXISTS `floor`;
CREATE TABLE `floor` (
  `id` int(11) NOT NULL,
  `name` text CHARACTER SET utf8 NOT NULL,
  `code` varchar(10) CHARACTER SET utf8 NOT NULL,
  `link` varchar(256) CHARACTER SET utf8 NOT NULL,
  `del` tinyint(4) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `floor`
--

INSERT INTO `floor` (`id`, `name`, `code`, `link`, `del`, `created_date`, `updated_date`) VALUES
(1, 'Sở giao dịch chứng khoán Hồ Chí Minh', 'HSX', 'https://www.hsx.vn/', 0, '2016-09-29 09:29:40', '2016-11-23 04:03:45'),
(2, 'Sở Giao dịch Chứng khoán Hà Nội', 'HNX', 'http://www.hnx.vn/', 0, '2016-10-05 07:27:31', '2016-10-05 07:27:31'),
(3, 'UPCOM', 'UPCOM', 'http://www.hnx.vn/', 0, '2016-10-05 08:36:54', '2016-10-05 08:37:16');
