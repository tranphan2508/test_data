
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(265) CHARACTER SET utf8 NOT NULL,
  `password` varchar(265) CHARACTER SET utf8 NOT NULL,
  `login_hash` varchar(265) CHARACTER SET utf8 NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `del` tinyint(4) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `login_hash`, `name`, `del`, `created_date`, `updated_date`) VALUES
(1, 'tranphan2508@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'b9cf0602545b5253caf624e045a32488', 'Tran Phan', 0, '2016-11-23 00:00:00', '2017-04-18 05:52:50');
