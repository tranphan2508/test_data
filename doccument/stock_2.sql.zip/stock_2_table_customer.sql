
-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `username` varchar(265) CHARACTER SET utf8 NOT NULL,
  `password` varchar(265) CHARACTER SET utf8 NOT NULL,
  `login_hash` varchar(265) CHARACTER SET utf8 NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `del` tinyint(4) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `username`, `password`, `login_hash`, `name`, `del`, `created_date`, `updated_date`) VALUES
(1, 'tranphan2508@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '4c8e1dbbbd75da45e486ce5ed51433bb', 'Tran Phan', 0, '2016-11-23 00:00:00', '2017-04-20 04:06:49');
